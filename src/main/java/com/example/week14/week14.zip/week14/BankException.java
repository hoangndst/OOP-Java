public class BankException extends Exception {

    /**
     * Constructor.
     * @param message the message
     */

    public BankException(String message) {
        super(message);
    }

}
